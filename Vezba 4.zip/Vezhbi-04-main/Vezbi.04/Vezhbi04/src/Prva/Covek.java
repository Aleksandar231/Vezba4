package Prva;

public class Covek {

	private String ime;
	private String prezime;
	private String embg;

	public Covek() {

	}

	public String getA() {
		return ime;
	}

	public void setA(String ime) {
		this.ime = ime;
	}

	public String getB() {
		return prezime;
	}

	public void setB(String prezime) {
		this.prezime = prezime;
	}

	public String getC() {
		return embg;
	}

	public void setC(String embg) {
		this.embg = embg;
	}
}
