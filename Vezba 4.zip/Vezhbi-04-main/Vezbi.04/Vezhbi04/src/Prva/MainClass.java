package Prva;

public class MainClass {

	public static void main(String[] args) {
		Covek c = new Covek();
		c.setA("Magdalena");
		c.setB("Apostolovska");
		c.setC("0809000415007");

		System.out.println(c.getA() + " " + c.getB() + " " + c.getC());

	}

}
