package Treta;

public class Proizvod {

	private String ime;
	private int cena;
	private String proizvoditel;
	private int tezina;

	public Proizvod() {
		this.ime = "Cokolado";
		this.cena = 180;
		this.proizvoditel = "Milka";
		this.tezina = 90;
	}

	public String getIme() {
		return ime;
	}

	public void setIme() {
	}

	public int getCena() {
		return cena;
	}

	public void setCena() {
	}

	public String getProizvoditel() {
		return proizvoditel;
	}

	public void setProizvoditel() {
	}

	public int getTezina() {
		return tezina;
	}

	public void setTezina() {
	}

}
